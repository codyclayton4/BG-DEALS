BG DEALS — PHONE PROTOTYPE

This is a Progressive Web App (PWA) prototype for Bowling Green, Kentucky.

To use it on iPhone:
1. Put these files on a web host that supports HTTPS.
2. Open the site's address in Safari.
3. Tap Share -> Add to Home Screen.
4. Launch BG Deals from the Home Screen.

Current version:
- Search
- Categories
- Deal cards
- Saved deals stored on the device
- Business placeholder
- Installable PWA shell

Next build:
- Real database
- Business accounts
- Deal submission/approval
- Business profiles
- Maps/location
- Push notifications
- Coupon redemption
- Admin dashboard
